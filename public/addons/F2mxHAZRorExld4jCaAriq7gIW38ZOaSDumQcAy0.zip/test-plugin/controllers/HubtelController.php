<?php

namespace App\Http\Controllers\Payment;

use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\WalletController;
use App\Http\Controllers\Controller;
use App\Http\Controllers\CustomerPackageController;
use App\Http\Controllers\SellerPackageController;
use App\Models\CombinedOrder;
use App\Models\PaymentMethod;
use App\Models\CustomerPackage;
use App\Models\Order;
use App\Models\SellerPackage;
use App\Models\Transaction;
use App\Models\User;
use Illuminate\Http\Request;
use Session;
use Auth;
use Http;

class HubtelController extends Controller
{
    public function __construct() {
        // Staff Permission Check
        $this->middleware(['permission:asian_payment_gateway_configuration'])->only('credentials_index');
    }

    public function pay(){
        $user = Auth::user();

        if ($user->phone == null) {
            flash('Please add phone number to your profile')->warning();
            return redirect()->route('profile');
        }
        if(Session::has('payment_type')){
            $paymentType = Session::get('payment_type');
            $paymentData = Session::get('payment_data');
            
            $transaction = new Transaction;
            $transaction->user_id = $user->id;
            $transaction->gateway = 'hubtel';
            $transaction->payment_type = $paymentType;
            $transaction->additional_content = json_encode($paymentData);
            $transaction->save();

            $amount = 0;
            $description = '';
            $callbackUrl = route('hubtel.callback');
            $returnUrl = route('home');
            $cancellationUrl = route('home');
            $clientReference = $transaction->id;

            if($paymentType == 'cart_payment'){
                $combined_order = CombinedOrder::findOrFail(Session::get('combined_order_id'));
                $amount = $combined_order->grand_total;
                $description = 'Cart Payment';
            }
            elseif($paymentType == 'order_re_payment'){
                $order = Order::findOrFail($paymentData['order_id']);
                $amount = $order->grand_total;
                $description = 'Order Re-Payment';
            }
            elseif ($paymentType == 'wallet_payment') {
                $amount = $paymentData['amount'];
                $description = 'Wallet Payment';
            }
            elseif($paymentType == 'customer_package_payment'){
                $customer_package = CustomerPackage::findOrFail($paymentData['customer_package_id']);
                $amount = $customer_package->amount;
                $description = 'Customer Package Payment';
            }
            elseif($paymentType == 'seller_package_payment'){
                $seller_package = SellerPackage::findOrFail($paymentData['seller_package_id']);
                $amount = $seller_package->amount;
                $description = 'Seller Package Payment';
            }

            $response = Http::withHeaders([
                'Authorization' => 'Basic ' + base64_encode(env('HUBTEL_API_KEY')),
                'Content-Type' => 'application/json',
                'Accept' => 'application/json'
            ])->post('https://payproxyapi.hubtel.com/items/initiate', [
                'totalAmount' => $amount,
                'description' => $description,
                'callbackUrl' => $callbackUrl,
                'returnUrl' => $returnUrl,
                'merchantAccountNumber' => env('HUBTEL_MERCHANT_ACCOUNT_NUMBER'),
                'cancellationUrl' => $cancellationUrl,
                'clientReference' => $clientReference
            ]);

            $responseBody = $response->json();

            if ($response->successful() && $responseBody['responseCode'] == '0000') {
                return redirect($responseBody['data']['checkoutUrl']);
            } else {
                flash('Payment initiation failed. Please try again.')->error();
                return back();
            }
        }
    }

    public function callback(Request $request){
        $transaction = Transaction::findOrFail($request->clientReference);

        if($request->status == 'Success'){
            $transaction->status = 'completed';
            $transaction->save();
            if($transaction->payment_type == 'cart_payment'){
                Auth::login(User::findOrFail($transaction->user_id));
                return (new CheckoutController)->checkout_done(json_decode($transaction->additional_content)->combined_order_id, json_encode($request->all()));
            }
            elseif($transaction->payment_type == 'order_re_payment'){
                Auth::login(User::findOrFail($transaction->user_id));
                return (new CheckoutController)->orderRePaymentDone(json_decode($transaction->additional_content, true), json_encode($request->all()));
            }
            elseif ($transaction->payment_type == 'wallet_payment') {
                Auth::login(User::findOrFail($transaction->user_id));
                return (new WalletController)->wallet_payment_done(json_decode($transaction->additional_content, true), json_encode($request->all()));
            }
            elseif ($transaction->payment_type == 'customer_package_payment') {
                Auth::login(User::findOrFail($transaction->user_id));
                return (new CustomerPackageController)->purchase_payment_done(json_decode($transaction->additional_content, true), json_encode($request->all()));
            }
            elseif ($transaction->payment_type == 'seller_package_payment') {
                Auth::login(User::findOrFail($transaction->user_id));
                return (new SellerPackageController)->purchase_payment_done(json_decode($transaction->additional_content, true), json_encode($request->all()));
            }
        } elseif($request->status == 'Cancelled') {
            $transaction->status = 'cancelled';
            $transaction->save();
            flash('Payment was cancelled.')->warning();
            return redirect()->route('home');
        } else {
            $transaction->status = 'failed';
            $transaction->save();
            flash('Payment failed. Please try again.')->error();
            return back();
        }
    }

    public function credentials_index()
    {
        $payment_methods = PaymentMethod::where('addon_identifier', 'hubtel')->get();
        return view('hubtel.index', compact('payment_methods'));
    }

    public function update_credentials(Request $request)
    {
        foreach ($request->types as $key => $type) {
            $this->overWriteEnvFile($type, $request[$type]);
        }

        flash("Settings updated successfully")->success();
        return back();
    }

    public function overWriteEnvFile($type, $val)
    {
        $path = base_path('.env');
        if (file_exists($path)) {
            $val = '"' . trim($val) . '"';
            if (is_numeric(strpos(file_get_contents($path), $type)) && strpos(file_get_contents($path), $type) >= 0) {
                file_put_contents($path, str_replace(
                    $type . '="' . env($type) . '"', $type . '=' . $val, file_get_contents($path)
                ));
            } else {
                file_put_contents($path, file_get_contents($path) . "\r\n" . $type . '=' . $val);
            }
        }
    }
}
