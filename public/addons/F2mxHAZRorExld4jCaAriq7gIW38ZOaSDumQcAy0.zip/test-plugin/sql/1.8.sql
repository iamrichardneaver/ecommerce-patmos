INSERT INTO `business_settings` (`id`, `type`, `value`, `lang`, `created_at`, `updated_at`) VALUES (NULL, 'phonepe_payment', '0', NULL, current_timestamp(), current_timestamp());
INSERT INTO `business_settings` (`id`, `type`, `value`, `lang`, `created_at`, `updated_at`) VALUES (NULL, 'phonepe_sandbox', '0', NULL, current_timestamp(), current_timestamp());

COMMIT;