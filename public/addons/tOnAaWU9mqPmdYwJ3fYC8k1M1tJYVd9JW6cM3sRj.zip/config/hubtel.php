<?php

return [
    'api_key' => env('HUBTEL_API_KEY'),
    'merchant_account_number' => env('HUBTEL_MERCHANT_ACCOUNT_NUMBER'),
];
