<?php

namespace App\Http\Controllers\Payment;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class HubtelController extends Controller
{
    public function pay(Request $request)
    {
        $paymentType = $request->session()->get('payment_type');
        $amount = 0;
        $description = '';

        switch ($paymentType) {
            case 'cart_payment':
                $amount = $request->session()->get('order_total');
                $description = 'Cart Payment';
                break;
            case 'wallet_payment':
                $amount = $request->session()->get('payment_data')['amount'];
                $description = 'Wallet Payment';
                break;
            case 'customer_package_payment':
                $amount = $request->session()->get('payment_data')['customer_package_amount'];
                $description = 'Customer Package Payment';
                break;
            case 'seller_package_payment':
                $amount = $request->session()->get('payment_data')['seller_package_amount'];
                $description = 'Seller Package Payment';
                break;
        }

        $response = Http::withHeaders([
            'Authorization' => 'Basic ' . base64_encode(env('HUBTEL_API_KEY')),
            'Content-Type' => 'application/json',
        ])->post('https://payproxyapi.hubtel.com/items/initiate', [
            'totalAmount' => $amount,
            'description' => $description,
            'callbackUrl' => route('hubtel.callback'),
            'returnUrl' => route('hubtel.return'),
            'merchantAccountNumber' => env('HUBTEL_MERCHANT_ACCOUNT_NUMBER'),
            'cancellationUrl' => route('hubtel.cancel'),
            'clientReference' => uniqid(),
        ]);

        $data = $response->json();

        if ($data['responseCode'] == '0000') {
            return redirect($data['data']['checkoutUrl']);
        } else {
            return back()->with('error', 'Payment initiation failed. Please try again.');
        }
    }

    public function callback(Request $request)
    {
        // Handle the callback from Hubtel
    }

    public function return(Request $request)
    {
        // Handle the return from Hubtel
    }

    public function cancel(Request $request)
    {
        // Handle the cancellation from Hubtel
    }
}
