<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Payment\HubtelController;

Route::post('/hubtel/pay', [HubtelController::class, 'pay'])->name('hubtel.pay');
Route::post('/hubtel/callback', [HubtelController::class, 'callback'])->name('hubtel.callback');
Route::get('/hubtel/return', [HubtelController::class, 'return'])->name('hubtel.return');
Route::get('/hubtel/cancel', [HubtelController::class, 'cancel'])->name('hubtel.cancel');
