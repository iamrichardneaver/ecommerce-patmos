<form class="form-horizontal" action="{{ route('payment_method.update') }}" method="POST">
    @csrf
    <input type="hidden" name="payment_method" value="hubtel">
    <div class="form-group row">
        <input type="hidden" name="types[]" value="HUBTEL_API_KEY">
        <div class="col-lg-4">
            <label class="col-from-label">{{ translate('HUBTEL API KEY') }}</label>
        </div>
        <div class="col-lg-8">
            <input type="text" class="form-control" name="HUBTEL_API_KEY"
                value="{{ env('HUBTEL_API_KEY') }}"
                placeholder="{{ translate('HUBTEL API KEY') }}" required>
        </div>
    </div>
    <div class="form-group row">
        <input type="hidden" name="types[]" value="HUBTEL_MERCHANT_ACCOUNT_NUMBER">
        <div class="col-lg-4">
            <label class="col-from-label">{{ translate('HUBTEL MERCHANT ACCOUNT NUMBER') }}</label>
        </div>
        <div class="col-lg-8">
            <input type="text" class="form-control" name="HUBTEL_MERCHANT_ACCOUNT_NUMBER"
                value="{{ env('HUBTEL_MERCHANT_ACCOUNT_NUMBER') }}"
                placeholder="{{ translate('HUBTEL MERCHANT ACCOUNT NUMBER') }}" required>
        </div>
    </div>
    <div class="form-group mb-0 text-right">
        <button type="submit" class="btn btn-sm btn-primary">{{ translate('Save') }}</button>
    </div>
</form>
